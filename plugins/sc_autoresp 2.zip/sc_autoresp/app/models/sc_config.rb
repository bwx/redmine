class ScConfig < ActiveRecord::Base

end
