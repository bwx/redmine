class ScLog < ActiveRecord::Base
end
