class MyPluginMailer < Mailer
end